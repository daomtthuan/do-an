package app.pattern;

public interface Model {
}
