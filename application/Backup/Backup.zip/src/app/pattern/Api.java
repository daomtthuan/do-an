package app.pattern;

public interface Api {
}
