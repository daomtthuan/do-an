package app.pattern;

public interface Controller {
}
