package controller.general;

import app.pattern.Controller;

public class BillDetail implements Controller {
}
